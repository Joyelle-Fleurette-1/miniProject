Part done by Joyelle Fleurette Ndikumana


Test 1
 - Test for comments
The output in lex should remove all the comments 

Test 2
 - Test for string
 - Test for strings that do not end till EOF
 - Test for headers

Test 3
Following errors must be detected
 - Invalid identifiers
 - Invalid operators
 - The output should display appropriate errors

 Test 4 is for varlist test