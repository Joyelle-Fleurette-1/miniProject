% comment
    
var a;
    
% This comment should be removed should be removed
	
interesting %