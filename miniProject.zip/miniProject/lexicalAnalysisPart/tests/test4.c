% comment
    
var x,abc,z;
    
% This comment should be removed should be removed
	
interesting %