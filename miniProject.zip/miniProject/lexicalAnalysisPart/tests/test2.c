#include<stdio.h>
#include <<stdlib.h>
#include "cast.h"
#include ""strong.h"
void main(){
	printf("This is a string");
	printf("This is a string that never terminates);
}