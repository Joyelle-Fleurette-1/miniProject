#include<stdio.h>
#include<stdlib.h>

var abc;
`
@ -
short int b;
var x, 3m, varrr$;
printf ("Varrr = %d \n \" ", varrr);