int main(){

   int a = 10;
   int b = 10

   for(a = 2 a<3; a++)
   b = b + 1;

   printf (" This string is enclosed in double quotes ");
   printf (" This string is not enclosed in double quotes );
   return 0;
}