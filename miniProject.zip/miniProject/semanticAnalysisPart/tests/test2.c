int main()
{
	int array1[10];
	int array2[20;

	for(int a = 3; a<4; a++
	{
		a = array1[0];
	}

	func();
}

int func()
{
	return 20;9