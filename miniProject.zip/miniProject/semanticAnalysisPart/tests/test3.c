int main()
{

  `
  @ -
  total = x @ y;

	int a = 4;

	if(a > 0 )
	{
		printf("a is positive");
		a * 2 = a;
	}
	else
	{
		printf("a is negative");
		a = a * 2;
	}

}